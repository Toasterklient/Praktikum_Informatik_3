# INF3_PRAK
Source code for practicals WS2019/2020
